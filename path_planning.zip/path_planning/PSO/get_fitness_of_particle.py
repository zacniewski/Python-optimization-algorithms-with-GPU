

def get_fitness_of_particle(particle, ):
    pass
